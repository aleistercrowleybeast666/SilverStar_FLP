from __future__ import annotations

ROCKET_FACE_COLORS_LIGHT = (
    "#FF5A5F",
    "#22C55E",
    "#3B82F6",
    "#F5B942",
    "#A8B3C2",
    "#7F8B9D",
)

ROCKET_FACE_COLORS_DARK = (
    "#FF7B86",
    "#4ADE80",
    "#60A5FA",
    "#FACC15",
    "#CBD5E1",
    "#94A3B8",
)

TRAJECTORY_DEPLOY_COLOR = "#F97316"
TRAJECTORY_DEPLOY_OUTLINE_LIGHT = "#172033"
TRAJECTORY_DEPLOY_OUTLINE_DARK = "#F8FAFC"


def RocketFaceColors_Get(theme: str) -> tuple[str, ...]:
    return ROCKET_FACE_COLORS_DARK if theme == "dark" else ROCKET_FACE_COLORS_LIGHT


def TrajectoryDeployOutlineColor_Get(theme: str) -> str:
    return (
        TRAJECTORY_DEPLOY_OUTLINE_DARK
        if theme == "dark"
        else TRAJECTORY_DEPLOY_OUTLINE_LIGHT
    )
