"""Desktop application entry points."""
