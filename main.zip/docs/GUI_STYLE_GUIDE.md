# SilverStar_FLP GUI style guide

The normative cross-project GUI specification is
[`CXYL_Python_GUI_STYLE_GUIDE.md`](CXYL_Python_GUI_STYLE_GUIDE.md). Read that document before
changing layout, navigation, controls, plots, Replay, 3D views, themes, or i18n. This file is the
short project entry point and does not duplicate the full CXYL guide.

SilverStar_FLP 0.0.2 fixes these project invariants:

- OS title is always `SilverStar_FLP`; the loaded filename appears only in status/details. On
  supported Windows versions, the native caption uses the current theme's brand blue.
- The header shows a localized descriptive name, `v0.0.2`, and localized developer credit.
  Language/theme fields and popups are deep blue with white text and accent-blue hover rows.
- File actions are ordered Import, Export, Save Project, Save Project As, Open Project in the
  menu; the toolbar omits Save As. Import and export remain modal option dialogs.
- Header, sidebar, menu, toolbar, and unselected tabs are deep blue. Selected navigation uses the
  same accent blue as Header combo hover with white text. All tabs retain their global style.
- A combo popup opens downward, shows at most ten rows, and scrolls internally beyond ten.
- Every page containing 2D plots provides one Reset Charts action for all plots on that page.
- Replay has no input selector and always requests `corrected_imu`. Replay owns the only editable
  Analysis Data Source selector; Recorded is first, and only complete successful runs are listed.
  Flight and State Estimation display the source read-only.
- Recorded Pure INS and Recorded KF_6 remain distinct visible layers. A plot refresh never reuses a
  color; after the base sixteen colors, generate additional HSV colors.
- Attitude uses the shared GSHC-proportion and GSHC face-color rocket mesh plus the existing WXYZ
  Body-to-ENU quaternion helper. Trajectory coordinates are relative to mission START. Deploy is
  an orange point with a theme-aware contrast outline; do not add floating event text.
- Playback updates geometry only. It must not reset orbit, pan, or zoom. Reset View is the explicit
  camera reset operation.
- Every user-visible Replay fidelity, warning, parameter, provenance, result, and source label must
  exist in both `zh_CN.json` and `en_US.json`; keep raw diagnostic IDs in tooltips.
