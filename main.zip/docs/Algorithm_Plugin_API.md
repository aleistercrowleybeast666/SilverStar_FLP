# Algorithm Plugin API

An `AlgorithmPlugin` declares stable identity/version metadata, required and optional records and
channels, a typed parameter schema, standard outputs, and diagnostic outputs. `availability()`
returns supported input sources, missing input codes, warnings, and `EXACT`, `APPROXIMATE`, or
`UNAVAILABLE`. `run()` receives a `ReplayRequest` and returns an immutable `AlgorithmResult`.

Standard output IDs such as `attitude.q_nb`, `navigation.velocity_enu`, and
`navigation.position_enu` let shared Navigation views work with future ESKF15/24 plugins. Plugin
specific channels such as `kf6.nis.position_horizontal` remain discoverable by Data Explorer and
diagnostic views without changing the common page.

Recorded, Recomputed, and What-if are provenance labels. Fidelity is separate: it describes input
and implementation completeness, never whether a curve merely looks close.

The desktop Replay page always constructs `ReplayRequest(input_source="corrected_imu")`. Plugins
must retain explicit availability checks and must not silently fall back. The internal API may
continue to accept `recorded_inertial_increment` for CLI, validation, and golden-vector work.

Each user-editable parameter supplies a stable `label_key`; the GUI translates that key and keeps
the raw `parameter_id` in the tooltip. Warnings remain stable raw codes in algorithm results and
are translated only at the GUI/export boundary.
